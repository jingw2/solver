from setuptools import find_packages, Extension, dist
import os 
try:
    from setuptools import setup
except:
    from distutils.core import setup

path = os.path.dirname(os.path.abspath(__file__))
# 增加README.md作为长描述文件
with open(os.path.join(path, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

# 必须装的环境
with open(os.path.join(path, "requirements.txt")) as fp:
    install_requires = fp.read().strip().split("\n")

VERSION = "0.0.2" # 每次更新的版本号需要不同，PyPI不支持覆盖
LICENSE = 'MIT'
setup(
      version=VERSION,
      setup_requires=["numpy"],
      install_requires=install_requires,
      name='forecastability',
      description='forecastability analysis',
      long_description=long_description,
      long_description_content_type='text/markdown',
      url='https://github.com/jingw2/solver/tree/master/forecastability',
      author='Jing Wang',
      author_email='jingw2@foxmail.com',
      license=LICENSE,
      packages=find_packages(),
      python_requires='>=3.6')
